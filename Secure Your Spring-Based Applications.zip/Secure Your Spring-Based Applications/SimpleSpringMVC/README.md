#Simple Spring MVC

Simple Spring MVC with jdbc dbcp connection to postgres.

This include - Forms, Validation, Session Management without using Spring Security.
